/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ipcwithsemaphores;
import java.util.concurrent.Semaphore;

import static ipcwithsemaphores.IPCWithSemaphores.*;

public class Producer extends Thread {
    private static int id;

    public Producer(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        while(true){
            if(itemsInStorage < maxStorageSpace){
                try {
                    semaphore.acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if(itemsInStorage >= maxStorageSpace){
                semaphore.release();
                return;
            }

            produceNewItem();
            System.out.println("Producer #"+this.id+" produced item, item count now:" + itemsInStorage);
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}
